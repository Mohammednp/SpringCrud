package in.test;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import in.controller.StudentController;
import in.dtobean.Student;

public class Test {

	public static void main(String[] args) {
		try (ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"\\in\\properties\\applicationContext.xml");) {

			StudentController stdController = (StudentController) context.getBean("stdController");
			Student std = (Student) context.getBean("std");

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			Integer option;
			try {
				while (true) {
					System.out.println("1. CREATE OR SAVE");
					System.out.println("2. SEARCH BY SID");
					System.out.println("3. UPDATE ");
					System.out.println("4. DELETE");
					System.out.println("5. EXIT");
					option = Integer.parseInt(br.readLine());
					String sid, sname, scity, scountry = null;
					switch (option) {
					case 1:
						System.out.println();
						System.out.println("-------------------------------");
						System.out.print("Enter SID      : ");
						sid = br.readLine();
						System.out.print("Enter SNAME    : ");
						sname = br.readLine();
						System.out.print("Enter SCITY    : ");
						scity = br.readLine();
						System.out.print("Enter SCOUNTRY : ");
						scountry = br.readLine();
						System.out.println("-------------------------------");
						System.out.println();

						std.setSid(sid);
						std.setSname(sname);
						std.setScity(scity);
						std.setScountry(scountry);

						String saveStudent = stdController.saveStudent(std);
						if (saveStudent != null) {
							if (saveStudent.equalsIgnoreCase("Success")) {
								System.out.println("Record Inserted Successfully....");
								System.out.println("-------------------------------");
								System.out.println();
							} else if (saveStudent.equalsIgnoreCase("Failure")) {
								System.out.println("Record Insertion Failure....");
								System.out.println("-------------------------------");
								System.out.println();
							} else {
								System.out.println("Unknown Status: " + saveStudent);
							}
						} else {
							System.out.println("Something went wrong... Record Insertion Failure....");
						}
						break;

					case 2:
						System.out.print("Enter SID      : ");
						sid = br.readLine();
						std = stdController.searchStudent(sid);
						if (std.getSid() != null) {
							System.out.println();
							System.out.println("-------------------------------");
							System.out.println("***Student Record***");
							System.out.println("SID       : " + std.getSid());
							System.out.println("SNAME     : " + std.getSname());
							System.out.println("SCITY     : " + std.getScity());
							System.out.println("SCOUNTRY  : " + std.getScountry());
							System.out.println("*********************");
							System.out.println("-------------------------------");
							System.out.println();
						} else {
							System.out.println("Record not available for the given id : " + sid);
						}
						break;

					case 3:
						System.out.print("Enter SID      : ");
						sid = br.readLine();
						std = stdController.searchStudent(sid);
						if (std.getSid() != null) {
							System.out.println();
							System.out.println("-------------------------------");
							System.out.println("***Student Record***");
							System.out.println("SID       : " + std.getSid());
							System.out.println("SNAME     : " + std.getSname());
							System.out.println("SCITY     : " + std.getScity());
							System.out.println("SCOUNTRY  : " + std.getScountry());
							System.out.println("*********************");
							System.out.println("-------------------------------");
							System.out.println();
						} else {
							System.out.println("Record not available for the given id : " + sid);
						}
						System.out.println("***Update Student Record Here***");
						System.out.println();
						System.out.println("-------------------------------");
						System.out.print("Enter SNAME    : ");
						sname = br.readLine();
						System.out.print("Enter SCITY    : ");
						scity = br.readLine();
						System.out.print("Enter SCOUNTRY : ");
						scountry = br.readLine();
						System.out.println("*******************************");
						System.out.println("-------------------------------");

						std.setSname(sname);
						std.setScity(scity);
						std.setScountry(scountry);
						String updateStudent = stdController.updateStudent(std);
						if (updateStudent != null) {
							if (updateStudent.equalsIgnoreCase("Success")) {
								System.out.println("Record Updated Successfully....");
								System.out.println("-------------------------------");
							} else if (updateStudent.equalsIgnoreCase("Failure")) {
								System.out.println("Record Updation Failure....");
								System.out.println("-------------------------------");
							} else {
								System.out.println("Unknown Status: " + updateStudent);
								System.out.println("-------------------------------");
							}
						} else {
							System.out.println("Something went wrong. Record Updation Failure....");
						}
						break;

					case 4:
						System.out.print("Enter SID      : ");
						sid = br.readLine();
						std = stdController.searchStudent(sid);
						if (std != null) {
							System.out.println();
							System.out.println("-------------------------------");
							System.out.println("***Student Record***");
							System.out.println("SID       : " + std.getSid());
							System.out.println("SNAME     : " + std.getSname());
							System.out.println("SCITY     : " + std.getScity());
							System.out.println("SCOUNTRY  : " + std.getScountry());
							System.out.println("*********************");
							System.out.println("-------------------------------");
							System.out.println();
						} else {
							System.out.println("Record not available for the given id : " + sid);
						}
						System.out.println("To Delete Above Record Press Y");
						String y = br.readLine();
						if (y.equalsIgnoreCase("Y")) {
							String deleteStudent = stdController.deleteStudent(sid);
							if (deleteStudent != null) {
								if (deleteStudent.equalsIgnoreCase("Success")) {
									System.out.println("Record Deleted Successfully....");
									System.out.println("-------------------------------");
								} else if (deleteStudent.equalsIgnoreCase("Failure")) {
									System.out.println("Record Deletion Failure....");
									System.out.println("-------------------------------");
								} else {
									System.out.println("Unknown Status: " + deleteStudent);
									System.out.println("-------------------------------");
								}
							} else {
								System.out.println("Something went wrong. Record Deletion Failure....");
							}
						} else {
							System.out.println("Invalid Key!");
						}
						break;
					case 5:
						System.out.println("---Thank You For Using The Application---");
						System.out.println("-----------------------------------------");
						System.exit(0);
					default:
						System.out.println("*** Please Choose Option [1,2,3,4] ***");
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}