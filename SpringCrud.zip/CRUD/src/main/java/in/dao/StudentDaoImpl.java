package in.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mysql.cj.jdbc.MysqlDataSource;

import in.dtobean.Student;

@Repository("stdDao")
public class StudentDaoImpl implements StudentDao {

	@Autowired
	private MysqlDataSource datasource;

	@Autowired
	private Student std;

	Connection con = null;
	PreparedStatement pstmnt = null;
	String status = null;
	int insert, update, delete;
	ResultSet record;

	private final String insertQuery = "INSERT INTO Student (sid,sname,scity,scountry) VALUES(?,?,?,?)";
	private final String readQuery = "SELECT *FROM Student WHERE sid=?";
	private final String updateQuery = "UPDATE Student SET sname=?, scity=?, scountry=? WHERE sid=?";
	private final String deleteQuery = "DELETE FROM Student WHERE sid=?";

	@Override
	public String saveStudent(Student student) {
		try {
			Connection con = datasource.getConnection();
			if (con != null) {
				pstmnt = con.prepareStatement(insertQuery);
			}
			if (pstmnt != null) {
				pstmnt.setString(1, student.getSid());
				pstmnt.setString(2, student.getSname());
				pstmnt.setString(3, student.getScity());
				pstmnt.setString(4, student.getScountry());

				insert = pstmnt.executeUpdate();
				if (insert == 1) {
					status = "Success";
				} else {
					status = "Failure";
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return status;
	}

	@Override
	public Student searchStudent(String sid) {
		try {
			Connection con = datasource.getConnection();
			if (con != null) {
				pstmnt = con.prepareStatement(readQuery);
			}
			if (pstmnt != null) {
				pstmnt.setString(1, sid);

				record = pstmnt.executeQuery();
				if (record.next()) {
					std.setSid(record.getString(1));
					std.setSname(record.getString(2));
					std.setScity(record.getString(3));
					std.setScountry(record.getString(4));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return std;
	}

	@Override
	public String updateStudent(Student student) {
		try {
			Connection con = datasource.getConnection();
			if (con != null) {
				pstmnt = con.prepareStatement(updateQuery);
			}
			if (pstmnt != null) {
				pstmnt.setString(1, student.getSname());
				pstmnt.setString(2, student.getScity());
				pstmnt.setString(3, student.getScountry());
				pstmnt.setString(4, student.getSid());

				update = pstmnt.executeUpdate();
				if (update == 1) {
					status = "Success";
				} else {
					status = "Failure";
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return status;
	}

	@Override
	public String deleteStudent(String sid) {
		try {
			con = datasource.getConnection();

			if (con != null) {
				pstmnt = con.prepareStatement(deleteQuery);
			}
			if (pstmnt != null) {
				pstmnt.setString(1, sid);

				delete = pstmnt.executeUpdate();
				if (delete == 1) {
					status = "Success";
				} else {
					status = "Failure";
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return status;
	}

}
