package in.service;

import in.dtobean.Student;

public interface StudentService {

	public String saveStudent(Student student);

	public Student searchStudent(String sid);

	public String updateStudent(Student student);

	public String deleteStudent(String sid);
}
