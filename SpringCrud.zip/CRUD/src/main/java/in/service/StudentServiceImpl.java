package in.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.dao.StudentDao;
import in.dtobean.Student;

@Service("stdService")
public class StudentServiceImpl implements StudentService {

	@Autowired
	StudentDao stdDao;

	@Override
	public String saveStudent(Student student) {
		String saveStudent = stdDao.saveStudent(student);
		return saveStudent;
	}

	@Override
	public Student searchStudent(String sid) {
		Student record = stdDao.searchStudent(sid);
		return record;
	}

	@Override
	public String updateStudent(Student student) {
		String updateStudent = stdDao.updateStudent(student);
		return updateStudent;
	}

	@Override
	public String deleteStudent(String sid) {
		String deleteStudent = stdDao.deleteStudent(sid);
		return deleteStudent;
	}

}
