package in.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import in.dtobean.Student;
import in.service.StudentService;

@Controller("stdController")
public class StudentControllerImpl implements StudentController {

	@Autowired
	StudentService stdService;

	@Override
	public String saveStudent(Student student) {
		String saveStudent = stdService.saveStudent(student);
		return saveStudent;
	}

	@Override
	public Student searchStudent(String sid) {
		Student record = stdService.searchStudent(sid);
		return record;
	}

	@Override
	public String updateStudent(Student student) {
		String updateStudent = stdService.updateStudent(student);
		return updateStudent;
	}

	@Override
	public String deleteStudent(String sid) {
		String deleteStudent = stdService.deleteStudent(sid);
		return deleteStudent;
	}

}
